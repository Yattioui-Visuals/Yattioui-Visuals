from django import forms
from django.core.exceptions import ValidationError
from django.forms import EmailInput, TextInput, Textarea, ImageField, Select
from .models import Reply, Post


class ReplyForm(forms.ModelForm):
    class Meta:
        model = Reply
        fields = ('name', 'email', 'content')

        widgets = {
            'name': TextInput(attrs={'class': 'form-control', 'autocomplete': 'off', 'pattern': '[A-Za-z ]+'}),
            'email': EmailInput(attrs={'class': 'form-control', 'autocomplete': 'off'}),
            'content': Textarea(attrs={'class': 'form-control', 'autcomplete': 'off'}),

        }


class CreatePostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ('title', 'content_preview', 'content', 'image')

        widgets = {
            'title': TextInput(attrs={'class': 'form-control', 'autocomplete': 'off', 'pattern': '[A-Za-z ]+'}),
            'content_preview': Textarea(attrs={'class': 'form-control', 'autcomplete': 'off'}),
            'content': Textarea(attrs={'class': 'form-control', 'autocomplete': 'off'}),

        }

from django.contrib import messages
from django.shortcuts import get_object_or_404
from django.urls import reverse_lazy
from django.views.generic import DetailView, FormView, ListView, DeleteView, UpdateView
from .forms import ReplyForm, CreatePostForm
from .models import Post, Reply


class HomeView(ListView):
    template_name = 'home.html'
    queryset = Post.objects.all()
    context_object_name = 'Post'


class ContentView(FormView, DetailView):
    template_name = 'page-content.html'
    queryset = Post.objects.all()
    form_class = ReplyForm
    success_url = reverse_lazy('content')

    def get_success_url(self):
        id_ = self.kwargs['pk']
        return reverse_lazy('content', kwargs={'pk': id_})

    def form_valid(self, form):
        form.instance.post_id = self.kwargs['pk']
        form.save()
        return super(ContentView, self).form_valid(form)

    def form_invalid(self, form):
        messages.warning(self.request, form.errors)
        return self.render_to_response(self.get_context_data(form=form))


class CreatePostView(FormView):
    template_name = 'create-post.html'
    form_class = CreatePostForm
    success_url = reverse_lazy('home')

    def form_valid(self, form):
        form.instance.author = self.request.user
        form.save()
        return super(CreatePostView, self).form_valid(form)

    def form_invalid(self, form):
        messages.warning(self.request, form.errors)
        return self.render_to_response(self.get_context_data(form=form))


class DeletePostView(DeleteView):
    model = Post
    template_name = "delete-post.html"
    success_url = reverse_lazy('home')

    def get_object(self):
        id_ = self.kwargs.get("id")
        return get_object_or_404(Post, id=id_)


class UpdatePostView(UpdateView):
    model = Post
    form_class = CreatePostForm
    template_name = "update-post.html"
    success_url = reverse_lazy('home')


class CreateReplyView(FormView):
    template_name = 'create-reply.html'
    form_class = ReplyForm
    success_url = reverse_lazy('content')

    def get_success_url(self):
        id_ = self.kwargs['pk']
        return reverse_lazy('content', kwargs={'pk': id_})

    def form_valid(self, form):
        form.instance.post_id = self.kwargs['pk']
        form.save()
        return super(CreateReplyView, self).form_valid(form)

    def form_invalid(self, form):
        messages.warning(self.request, form.errors)
        return self.render_to_response(self.get_context_data(form=form))


class UpdateReplyView(UpdateView):
    model = Reply
    form_class = ReplyForm
    template_name = "update-reply.html"
    success_url = reverse_lazy('home')

class DeleteReplyView(DeleteView):
    model = Reply
    template_name = "delete-reply.html"
    success_url = reverse_lazy('home')

    def get_object(self):
        id_ = self.kwargs.get("id")
        return get_object_or_404(Reply, id=id_)